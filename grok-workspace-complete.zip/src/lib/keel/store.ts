import { create } from "zustand";
import { persist } from "zustand/middleware";
import { defaultSettings, sampleBots, sampleMessages } from "@/lib/keel/seed";
import type {
  Bot,
  ChatMessage,
  Screen,
  Settings,
  Sheet,
} from "@/lib/keel/types";

type KeelState = {
  bots: Bot[];
  messages: ChatMessage[];
  settings: Settings;
  screen: Screen;
  openBotId: string | null;
  sheet: Sheet;
  setScreen: (screen: Screen) => void;
  setSheet: (sheet: Sheet) => void;
  openBot: (id: string, screen?: Screen) => void;
  patchBot: (id: string, patch: Partial<Bot>) => void;
  addMessage: (message: ChatMessage) => void;
  patchMessage: (id: string, patch: Partial<ChatMessage>) => void;
  setSettings: (patch: Partial<Settings>) => void;
  addBot: (bot: Bot) => void;
  removeBot: (id: string) => void;
  loadSample: () => void;
  clearDesk: () => void;
};

export const useKeel = create<KeelState>()(
  persist(
    (set) => ({
      bots: sampleBots(),
      messages: sampleMessages(),
      settings: defaultSettings,
      screen: "roster",
      openBotId: null,
      sheet: null,
      setScreen: (screen) => set({ screen }),
      setSheet: (sheet) => set({ sheet }),
      openBot: (id, screen = "chat") =>
        set((s) => ({
          screen,
          openBotId: id,
          bots: s.bots.map((b) => (b.id === id ? { ...b, unread: 0 } : b)),
        })),
      patchBot: (id, patch) =>
        set((s) => ({
          bots: s.bots.map((b) => (b.id === id ? { ...b, ...patch } : b)),
        })),
      addMessage: (message) =>
        set((s) => {
          const mine = s.messages.filter((m) => m.botId === message.botId);
          const others = s.messages.filter((m) => m.botId !== message.botId);
          const next = mine.concat(message).slice(-80);
          return { messages: others.concat(next) };
        }),
      patchMessage: (id, patch) =>
        set((s) => ({
          messages: s.messages.map((m) => (m.id === id ? { ...m, ...patch } : m)),
        })),
      setSettings: (patch) =>
        set((s) => ({ settings: { ...s.settings, ...patch } })),
      addBot: (bot) => set((s) => ({ bots: s.bots.concat(bot) })),
      removeBot: (id) =>
        set((s) => ({
          bots: s.bots.filter((b) => b.id !== id),
          messages: s.messages.filter((m) => m.botId !== id),
          openBotId: s.openBotId === id ? null : s.openBotId,
          screen: s.openBotId === id ? "roster" : s.screen,
          sheet: null,
        })),
      loadSample: () =>
        set({
          bots: sampleBots(),
          messages: sampleMessages(),
          screen: "roster",
          openBotId: null,
          sheet: null,
        }),
      clearDesk: () =>
        set({
          bots: [],
          messages: [],
          screen: "roster",
          openBotId: null,
          sheet: null,
        }),
    }),
    {
      name: "keel-desk-v1",
      skipHydration: true,
      partialize: (s) => ({
        bots: s.bots,
        messages: s.messages,
        settings: s.settings,
      }),
    },
  ),
);

export function uid(): string {
  return Math.random().toString(36).slice(2, 8) + Date.now().toString(36);
}
