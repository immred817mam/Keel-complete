import { runAgent } from "@/lib/keel/agent.functions";
import { uid, useKeel } from "@/lib/keel/store";
import type {
  Activity,
  AgentStep,
  Bot,
  BotStatus,
  ChatMessage,
  DraftCard,
  Source,
} from "@/lib/keel/types";

const generation: Record<string, number> = {};

export function askBot(botId: string, cue: string) {
  const text = cue.trim();
  if (!text) return;
  const keel = useKeel.getState();
  const bot = keel.bots.find((item) => item.id === botId);
  if (!bot || bot.status === "working") return;

  const gen = (generation[botId] = (generation[botId] ?? 0) + 1);
  const alive = () => generation[botId] === gen;

  keel.openBot(botId, "chat");
  keel.addMessage({
    id: uid(),
    botId,
    role: "user",
    text,
    at: Date.now(),
  });
  keel.patchBot(botId, {
    status: "working",
    statusLine: "Working…",
    updatedAt: Date.now(),
    unread: 0,
  });

  void work(botId, text, alive);
}

export function stopBot(botId: string) {
  generation[botId] = (generation[botId] ?? 0) + 1;
  const keel = useKeel.getState();
  keel.patchBot(botId, {
    status: "idle",
    statusLine: "Stopped.",
    updatedAt: Date.now(),
  });
  keel.addMessage({
    id: uid(),
    botId,
    role: "bot",
    text: "Stopped. Nothing went out.",
    at: Date.now(),
  });
}

async function work(botId: string, cue: string, alive: () => boolean) {
  const keel = useKeel.getState();
  const settings = keel.settings;
  let history = historyFor(botId).slice(0, -1);
  let nextCue = cue;
  let steps: AgentStep[] = [];
  let liveId: string | null = null;
  let stop: "chat" | "draft" | "ask" | "handoff" | "done" | "error" = "chat";
  let error = "";
  let truncated = false;

  try {
    for (let round = 0; round < 3; round += 1) {
      const snapshot = useKeel.getState();
      const bot = snapshot.bots.find((item) => item.id === botId);
      if (!bot || !alive()) return;
      const sent = nextCue;
      const result = await runAgent({
        data: {
          engine: settings.engine,
          apiKey: settings.engine === "open" ? undefined : settings.apiKey,
          model: settings.model || undefined,
          bot: {
            name: bot.name,
            role: bot.role,
            brief: bot.brief,
            memory: bot.memory.slice(-16),
            files: bot.files.slice(0, 12).map((file) => ({
              path: file.path,
              content: file.content.slice(0, 2500),
            })),
          },
          roster: snapshot.bots
            .filter((item) => item.id !== botId)
            .map((item) => ({ name: item.name, role: item.role })),
          history: history.slice(-14),
          cue: nextCue,
        },
      });
      if (!alive()) return;
      if (result.stop === "error") {
        stop = "error";
        error = result.error || "The model didn't answer.";
        break;
      }
      steps = steps.concat(result.steps);
      applySideEffects(botId, result.steps);
      const view = project(steps);
      if (!view.text && result.stop === "continue") {
        view.text = "Still on it.";
      }
      liveId = upsertLive(botId, liveId, view);
      useKeel.getState().patchBot(botId, {
        status: "working",
        statusLine: lineFrom(view.text, "Working…"),
        updatedAt: Date.now(),
      });
      if (result.stop !== "continue") {
        stop = result.stop;
        break;
      }
      history = history.concat(
        { role: "user", content: sent },
        { role: "assistant", content: result.raw || view.text },
        { role: "user", content: result.observation || "Continue. JSON only." },
      );
      nextCue = "Continue from the tool result. Do not repeat the same tool. JSON only.";
      truncated = true;
    }
    if (stop !== "chat") truncated = false;
  } catch (caught) {
    if (!alive()) return;
    stop = "error";
    error = caught instanceof Error ? caught.message : "The model didn't answer.";
  }

  if (!alive()) return;
  finish(botId, liveId, steps, stop, error, truncated);
}

function finish(
  botId: string,
  liveId: string | null,
  steps: AgentStep[],
  stop: "chat" | "draft" | "ask" | "handoff" | "done" | "error",
  error: string,
  truncated: boolean,
) {
  const view = project(steps);
  let text = view.text;
  if (stop === "error") {
    text = view.text ? `${view.text}\n\n${error || "I couldn't reach the model."}` : error || "I couldn't reach the model.";
  }
  if (!text) {
    text =
      stop === "draft"
        ? "Draft is ready. Nothing is shared until you say so."
        : "I paused here. Tell me how to continue.";
  }
  if (truncated) {
    text = `${text}\n\nI paused so this doesn't run on. Tell me to continue.`;
  }
  if (stop === "handoff") text = applyHandoff(botId, steps, text);

  const status: BotStatus =
    stop === "draft" || stop === "ask" ? "needs_you" : stop === "done" ? "done" : "idle";
  const statusLine =
    stop === "error"
      ? "Couldn't reach the model."
      : stop === "draft"
        ? "Waiting on your OK."
        : lineFrom(text, "Ready.");

  upsertLive(botId, liveId, { ...view, text });
  const viewing =
    useKeel.getState().openBotId === botId && useKeel.getState().screen !== "roster";
  const current = useKeel.getState().bots.find((item) => item.id === botId);
  useKeel.getState().patchBot(botId, {
    status,
    statusLine,
    updatedAt: Date.now(),
    unread: viewing ? 0 : (current?.unread ?? 0) + 1,
  });
}

function upsertLive(
  botId: string,
  liveId: string | null,
  view: { text: string; activity: Activity[]; draft?: DraftCard },
): string {
  const keel = useKeel.getState();
  if (!liveId) {
    const id = uid();
    keel.addMessage({
      id,
      botId,
      role: "bot",
      text: view.text,
      at: Date.now(),
      activity: view.activity,
      draft: view.draft,
    });
    return id;
  }
  keel.patchMessage(liveId, {
    text: view.text,
    activity: view.activity,
    draft: view.draft,
  });
  return liveId;
}

function applySideEffects(botId: string, steps: AgentStep[]) {
  const bot = useKeel.getState().bots.find((item) => item.id === botId);
  if (!bot) return;
  let files = bot.files;
  let memory = bot.memory;
  let sources = bot.sources;
  for (const step of steps) {
    if (step.kind === "write") {
      files = [
        { path: step.path, content: step.content, updatedAt: Date.now() },
        ...files.filter((file) => file.path !== step.path),
      ].slice(0, 20);
    }
    if (step.kind === "remember" && !memory.includes(step.fact)) {
      memory = memory.concat(step.fact).slice(-24);
    }
    if (step.kind === "search") sources = mergeSources(sources, step.hits);
    if (step.kind === "browse") {
      sources = mergeSources(sources, [
        { title: step.title, url: step.url, snippet: step.excerpt.slice(0, 180) },
      ]);
    }
  }
  useKeel.getState().patchBot(botId, { files, memory, sources });
}

function mergeSources(current: Source[], incoming: Source[]): Source[] {
  const next = current.slice();
  for (const hit of incoming) {
    if (!hit.url || next.some((item) => item.url === hit.url)) continue;
    next.unshift(hit);
  }
  return next.slice(0, 8);
}

function applyHandoff(botId: string, steps: AgentStep[], text: string): string {
  const handoff = [...steps].reverse().find((step) => step.kind === "handoff");
  if (handoff?.kind !== "handoff") return text;
  const from = useKeel.getState().bots.find((item) => item.id === botId);
  const target = useKeel.getState().bots.find((item) => {
    const name = item.name.toLowerCase();
    const wanted = handoff.botName.toLowerCase();
    return item.id !== botId && (name === wanted || name.includes(wanted) || wanted.includes(name));
  });
  if (!from || !target) {
    return `${text}\n\nI couldn't find ${handoff.botName} on this desk.`;
  }
  useKeel.getState().addMessage({
    id: uid(),
    botId: target.id,
    role: "bot",
    text: `${from.name} handed this over: ${handoff.note}`,
    at: Date.now(),
  });
  useKeel.getState().patchBot(target.id, {
    status: "needs_you",
    statusLine: `Note from ${from.name}.`,
    updatedAt: Date.now(),
    unread: target.unread + 1,
  });
  return text;
}

function project(steps: AgentStep[]): {
  text: string;
  activity: Activity[];
  draft?: DraftCard;
} {
  const says: string[] = [];
  const activity: Activity[] = [];
  let draft: DraftCard | undefined;
  let ask = "";
  let done = "";
  for (const step of steps) {
    if (step.kind === "say" && step.text) says.push(step.text);
    if (step.kind === "search") {
      activity.push({
        label: "Searched the web",
        detail: step.query,
        links: step.hits.map((hit) => ({ title: hit.title, url: hit.url })),
      });
    }
    if (step.kind === "browse") {
      activity.push({
        label: "Read a page",
        detail: step.title,
        links: [{ title: step.title || step.url, url: step.url }],
      });
    }
    if (step.kind === "read") activity.push({ label: "Opened a file", detail: step.path });
    if (step.kind === "write") activity.push({ label: `Wrote ${step.path}` });
    if (step.kind === "remember") activity.push({ label: "Remembered", detail: step.fact });
    if (step.kind === "handoff") {
      activity.push({ label: `Handed to ${step.botName}`, detail: step.note });
    }
    if (step.kind === "draft") {
      draft = {
        channel: step.channel,
        title: step.title,
        to: step.to,
        subject: step.subject,
        body: step.body,
        state: "pending",
      };
    }
    if (step.kind === "ask") ask = step.question;
    if (step.kind === "done") done = step.summary;
  }
  let text = says.join("\n\n");
  if (ask && !text.includes(ask)) text = text ? `${text}\n\n${ask}` : ask;
  if (done && !text.includes(done)) text = text ? `${text}\n\n${done}` : done;
  return { text, activity, draft };
}

function historyFor(botId: string): { role: "user" | "assistant"; content: string }[] {
  return useKeel
    .getState()
    .messages.filter((message) => message.botId === botId)
    .slice(-12)
    .map((message) => ({
      role: message.role === "user" ? "user" : "assistant",
      content: messageBody(message),
    }));
}

function messageBody(message: ChatMessage): string {
  const bits = [message.text];
  for (const item of message.activity ?? []) {
    bits.push(`${item.label}${item.detail ? `: ${item.detail}` : ""}`);
  }
  if (message.draft) {
    bits.push(`Draft (${message.draft.state}): ${message.draft.title}\n${message.draft.body}`);
  }
  return bits.join("\n").slice(0, 3500);
}

function lineFrom(text: string, fallback: string): string {
  const line = text.split("\n").map((part) => part.trim()).find(Boolean);
  return (line ?? fallback).slice(0, 90);
}

export function saveDraftFile(bot: Bot, draft: DraftCard) {
  const slug = draft.title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 40) || "draft";
  const path = `ready/${slug}.md`;
  const content = [
    `# ${draft.title}`,
    draft.to ? `To: ${draft.to}` : "",
    draft.subject ? `Subject: ${draft.subject}` : "",
    "",
    draft.body,
  ]
    .filter((line, index, all) => line !== "" || all[index - 1] !== "")
    .join("\n");
  useKeel.getState().patchBot(bot.id, {
    files: [
      { path, content, updatedAt: Date.now() },
      ...bot.files.filter((file) => file.path !== path),
    ],
    status: "done",
    statusLine: "Saved on the desk.",
    updatedAt: Date.now(),
  });
  return path;
}
