export type Engine = "open" | "groq" | "gemini" | "openrouter";

export type BotShape = "circle" | "squircle" | "tile";

export type BotStatus = "idle" | "working" | "needs_you" | "done";

export type Routine = {
  id: string;
  label: string;
  prompt: string;
  when: "manual" | "on_open";
  lastRun: number;
};

export type DeskFile = {
  path: string;
  content: string;
  updatedAt: number;
};

export type Source = {
  title: string;
  url: string;
  snippet: string;
};

export type Bot = {
  id: string;
  name: string;
  role: string;
  brief: string;
  shape: BotShape;
  tone: "ink" | "copper";
  status: BotStatus;
  statusLine: string;
  updatedAt: number;
  unread: number;
  memory: string[];
  files: DeskFile[];
  sources: Source[];
  routines: Routine[];
  prompts: string[];
};

export type Activity = {
  label: string;
  detail?: string;
  links?: { title: string; url: string }[];
};

export type DraftChannel = "email" | "message" | "post";

export type DraftCard = {
  channel: DraftChannel;
  title: string;
  to: string;
  subject: string;
  body: string;
  state: "pending" | "approved" | "discarded";
};

export type ChatMessage = {
  id: string;
  botId: string;
  role: "user" | "bot";
  text: string;
  at: number;
  activity?: Activity[];
  draft?: DraftCard;
};

export type Settings = {
  engine: Engine;
  apiKey: string;
  model: string;
  installHint: boolean;
};

export type Screen = "roster" | "chat" | "computer";

export type Sheet = null | "settings" | "create" | "edit" | "install";

export type AgentStep =
  | { kind: "say"; text: string }
  | { kind: "search"; query: string; hits: Source[] }
  | { kind: "browse"; url: string; title: string; excerpt: string }
  | { kind: "read"; path: string }
  | { kind: "write"; path: string; content: string }
  | { kind: "remember"; fact: string }
  | {
      kind: "draft";
      channel: DraftChannel;
      title: string;
      to: string;
      subject: string;
      body: string;
    }
  | { kind: "ask"; question: string }
  | { kind: "handoff"; botName: string; note: string }
  | { kind: "done"; summary: string };

export type AgentStop =
  | "continue"
  | "chat"
  | "draft"
  | "ask"
  | "handoff"
  | "done"
  | "error";

export type AgentResult = {
  steps: AgentStep[];
  stop: AgentStop;
  observation: string;
  raw: string;
  error?: string;
};
