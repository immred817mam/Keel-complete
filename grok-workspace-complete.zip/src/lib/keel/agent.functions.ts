import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type { AgentResult, AgentStep, DraftChannel, Source } from "@/lib/keel/types";

const TurnInput = z.object({
  engine: z.enum(["open", "groq", "gemini", "openrouter"]),
  apiKey: z.string().max(400).optional(),
  model: z.string().max(120).optional(),
  bot: z.object({
    name: z.string().max(48),
    role: z.string().max(64),
    brief: z.string().max(800),
    memory: z.array(z.string().max(220)).max(24),
    files: z
      .array(
        z.object({
          path: z.string().max(80),
          content: z.string().max(2500),
        }),
      )
      .max(16),
  }),
  roster: z
    .array(z.object({ name: z.string().max(48), role: z.string().max(64) }))
    .max(16),
  history: z
    .array(
      z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string().max(4000),
      }),
    )
    .max(18),
  cue: z.string().min(1).max(4000),
});

type Turn = z.infer<typeof TurnInput>;

const runAgent = createServerFn({ method: "POST" })
  .validator((input: unknown) => TurnInput.parse(input))
  .handler(async ({ data }): Promise<AgentResult> => {
    try {
      return await oneTurn(data);
    } catch (error) {
      const message = error instanceof Error ? error.message : "The model didn't answer.";
      return {
        steps: [],
        stop: "error",
        observation: "",
        raw: "",
        error: message.slice(0, 280),
      };
    }
  });

export { runAgent };

async function oneTurn(data: Turn): Promise<AgentResult> {
  const system = systemPrompt(data);
  const messages = [
    { role: "system" as const, content: system },
    ...data.history,
    { role: "user" as const, content: data.cue },
  ];
  const raw = (await complete(messages, data)).trim();
  const turn = interpret(raw);
  const say = turn.say;
  const tool = turn.tool;
  const args = turn.args;

  if (tool === "search") {
    const query = str(args.query).slice(0, 180);
    if (!query) return chatStop(say || raw);
    const hits = await searchWeb(query);
    const step: AgentStep = { kind: "search", query, hits };
    return {
      steps: compact(say, step),
      stop: "continue",
      observation: formatHits(query, hits),
      raw: clip(raw),
    };
  }

  if (tool === "browse") {
    const url = str(args.url);
    const page = await browse(url);
    const step: AgentStep = {
      kind: "browse",
      url: page.url,
      title: page.title,
      excerpt: page.excerpt,
    };
    return {
      steps: compact(say, step),
      stop: "continue",
      observation: `Tool result (browse) ${page.url}\n${page.title}\n${page.excerpt}`,
      raw: clip(raw),
    };
  }

  if (tool === "read") {
    const path = safePath(str(args.path));
    const file = data.bot.files.find((f) => f.path === path);
    const body = file ? file.content : "(no such file)";
    return {
      steps: compact(say, { kind: "read", path }),
      stop: "continue",
      observation: `Tool result (read) ${path}\n${body.slice(0, 1800)}`,
      raw: clip(raw),
    };
  }

  if (tool === "write") {
    const path = safePath(str(args.path));
    const content = str(args.content).slice(0, 6000);
    if (!content) return chatStop(say || "I didn't have anything solid to file.");
    return {
      steps: compact(say, { kind: "write", path, content }),
      stop: "continue",
      observation: `Tool result (write): saved ${path} (${content.length} characters). If the task is finished, use done or draft. JSON only.`,
      raw: clip(raw),
    };
  }

  if (tool === "remember") {
    const fact = str(args.fact).slice(0, 200);
    if (!fact) return chatStop(say || raw);
    return {
      steps: compact(say, { kind: "remember", fact }),
      stop: "continue",
      observation: `Tool result (remember): noted "${fact}". Continue. JSON only.`,
      raw: clip(raw),
    };
  }

  if (tool === "draft") {
    const body = str(args.body).slice(0, 4000);
    const step: AgentStep = {
      kind: "draft",
      channel: channelOf(args.channel),
      title: str(args.title).slice(0, 80) || "Draft",
      to: str(args.to).slice(0, 80),
      subject: str(args.subject).slice(0, 140),
      body: body || say,
    };
    return { steps: compact(say, step), stop: "draft", observation: "", raw: clip(raw) };
  }

  if (tool === "ask") {
    const question = str(args.question).slice(0, 400) || say;
    return {
      steps: compact(say, { kind: "ask", question }),
      stop: "ask",
      observation: "",
      raw: clip(raw),
    };
  }

  if (tool === "handoff") {
    const botName = str(args.botName).slice(0, 48);
    const note = str(args.note).slice(0, 800);
    if (!botName || !note) return chatStop(say || raw);
    return {
      steps: compact(say, { kind: "handoff", botName, note }),
      stop: "handoff",
      observation: "",
      raw: clip(raw),
    };
  }

  if (tool === "done") {
    const summary = str(args.summary).slice(0, 600) || say;
    return {
      steps: compact(say, { kind: "done", summary }),
      stop: "done",
      observation: "",
      raw: clip(raw),
    };
  }

  return chatStop(say || stripJsonNoise(raw));
}

function chatStop(text: string): AgentResult {
  const clean = text.trim().slice(0, 2000);
  return {
    steps: clean ? [{ kind: "say", text: clean }] : [],
    stop: "chat",
    observation: "",
    raw: clip(clean),
  };
}

function compact(say: string, step: AgentStep): AgentStep[] {
  const steps: AgentStep[] = [];
  if (say && step.kind !== "say") steps.push({ kind: "say", text: say });
  steps.push(step);
  return steps;
}

function systemPrompt(data: Turn): string {
  const roster = data.roster.map((b) => `${b.name} (${b.role})`).join(", ") || "none";
  const memory = data.bot.memory.join("\n- ") || "none yet";
  const files =
    data.bot.files
      .map((f) => `- ${f.path}: ${f.content.slice(0, 180).replace(/\s+/g, " ")}`)
      .join("\n") || "empty";
  return `You are ${data.bot.name}, a coworker (${data.bot.role}) in a phone app called Keel.
Voice: ${data.bot.brief}

Reply with ONE JSON object and nothing else. No markdown.
{"say":"1-2 sentences","tool":"none","args":{}}

Tools and args:
- none {} just talk
- search {"query":"..."} public web. Use before facts you are not sure of.
- browse {"url":"https://..."} one public page
- read {"path":"folder/file.md"} a desk file
- write {"path":"folder/file.md","content":"..."} save real work on the desk
- remember {"fact":"one sentence"} a durable preference
- draft {"channel":"email|message|post","title":"...","to":"...","subject":"...","body":"..."} then stop. You cannot send.
- ask {"question":"..."} one decision you need, then stop
- handoff {"botName":"...","note":"..."} pass work to a coworker, then stop
- done {"summary":"..."} when the task is finished

Rules:
- You cannot email, post, pay, or sign in. Never claim you sent something.
- Put long writing in write or draft, not in say.
- After search or browse, do not call that same tool again. Write, draft, or done.
- Do not invent sources, numbers, or tool results.
- Other coworkers: ${roster}
- Memory:
- ${memory}
- Desk files:
${files}`;
}

type Msg = { role: "system" | "user" | "assistant"; content: string };

async function complete(messages: Msg[], data: Turn): Promise<string> {
  if (data.engine === "open") return completeOpen(messages);
  const key = (data.apiKey ?? "").trim();
  if (!key) {
    throw new Error("Add a free API key in Settings, or switch the engine back to Open model.");
  }
  if (data.engine === "groq") return completeOpenAI(messages, data, key, "https://api.groq.com/openai/v1/chat/completions", data.model?.trim() || "llama-3.3-70b-versatile");
  if (data.engine === "openrouter") {
    return completeOpenAI(
      messages,
      data,
      key,
      "https://openrouter.ai/api/v1/chat/completions",
      data.model?.trim() || "meta-llama/llama-3.3-70b-instruct:free",
    );
  }
  return completeGemini(messages, key, data.model?.trim() || "gemini-2.5-flash");
}

async function completeOpen(messages: Msg[]): Promise<string> {
  const res = await fetch("https://text.pollinations.ai/openai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "gpt-oss-20b",
      messages,
      temperature: 0.3,
      max_tokens: 700,
    }),
    signal: AbortSignal.timeout(42000),
  });
  const body = await res.text();
  if (!res.ok) throw new Error(publicError(res.status, body));
  return contentFromOpenAI(body);
}

async function completeOpenAI(
  messages: Msg[],
  _data: Turn,
  key: string,
  url: string,
  model: string,
): Promise<string> {
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${key}`,
    },
    body: JSON.stringify({
      model,
      messages,
      temperature: 0.3,
      max_tokens: 700,
    }),
    signal: AbortSignal.timeout(42000),
  });
  const body = await res.text();
  if (!res.ok) throw new Error(publicError(res.status, body, key));
  return contentFromOpenAI(body);
}

function contentFromOpenAI(body: string): string {
  const json = JSON.parse(body) as {
    choices?: { message?: { content?: string } }[];
  };
  const content = json.choices?.[0]?.message?.content ?? "";
  if (!content.trim()) throw new Error("The model returned an empty reply.");
  return content;
}

async function completeGemini(messages: Msg[], key: string, model: string): Promise<string> {
  const system = messages.find((m) => m.role === "system")?.content ?? "";
  const contents = messages
    .filter((m) => m.role !== "system")
    .map((m) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content }],
    }));
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: system }] },
      contents,
      generationConfig: { temperature: 0.3, maxOutputTokens: 700 },
    }),
    signal: AbortSignal.timeout(42000),
  });
  const body = await res.text();
  if (!res.ok) throw new Error(publicError(res.status, body, key));
  const json = JSON.parse(body) as {
    candidates?: { content?: { parts?: { text?: string }[] } }[];
  };
  const text = json.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "";
  if (!text.trim()) throw new Error("Gemini returned an empty reply.");
  return text;
}

function publicError(status: number, body: string, key?: string): string {
  if (status === 402 || status === 429) {
    return "The free model lane is busy. Wait a minute, or add a free Groq, Gemini, or OpenRouter key in Settings.";
  }
  if (status === 401 || status === 403) {
    return "That key was refused. Check it in Settings, or switch to the open model.";
  }
  let text = body.replace(/\s+/g, " ").slice(0, 160);
  if (key && key.length > 6) text = text.split(key).join("…");
  return `The model didn't answer (${status}). ${text}`;
}

function interpret(raw: string): { say: string; tool: string; args: Record<string, unknown> } {
  let text = raw.replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence?.[1]) text = fence[1].trim();
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start >= 0 && end > start) {
    try {
      const obj = JSON.parse(text.slice(start, end + 1)) as Record<string, unknown>;
      const say = str(obj.say);
      const tool = str(obj.tool).toLowerCase() || "none";
      const args =
        obj.args && typeof obj.args === "object"
          ? (obj.args as Record<string, unknown>)
          : obj;
      return { say, tool, args };
    } catch {
      /* prose fallback */
    }
  }
  return { say: stripJsonNoise(text), tool: "none", args: {} };
}

function stripJsonNoise(text: string): string {
  return text.replace(/```[\s\S]*?```/g, "").trim();
}

function str(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function clip(value: string): string {
  return value.slice(0, 2000);
}

function channelOf(value: unknown): DraftChannel {
  return value === "message" || value === "post" ? value : "email";
}

function safePath(path: string): string {
  const clean = path
    .replace(/\\/g, "/")
    .replace(/^\/+/, "")
    .replace(/\.\./g, "")
    .replace(/[^a-zA-Z0-9._\-/ ]/g, "")
    .trim()
    .slice(0, 80);
  return clean || "notes/note.md";
}

function formatHits(query: string, hits: Source[]): string {
  if (!hits.length) {
    return `Tool result (search) for ${query}: no useful public hits. Say so. Do not invent facts. JSON only.`;
  }
  const lines = hits
    .map((h) => `- ${h.title} | ${h.url}\n  ${h.snippet}`)
    .join("\n");
  return `Tool result (search) for ${query}:\n${lines}\nUse this. Do not search the same query again. JSON only.`;
}

async function searchWeb(query: string): Promise<Source[]> {
  const hits: Source[] = [];
  const [wiki, ddg] = await Promise.all([wikiSearch(query), ddgSearch(query)]);
  for (const hit of wiki.concat(ddg)) {
    if (hits.some((h) => h.url === hit.url)) continue;
    hits.push(hit);
    if (hits.length >= 4) break;
  }
  return hits;
}

async function wikiSearch(query: string): Promise<Source[]> {
  try {
    const url = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&utf8=1&format=json&srlimit=3`;
    const res = await fetch(url, {
      headers: { "User-Agent": "Keel/1.0 (phone coworker app; public research)" },
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return [];
    const json = (await res.json()) as {
      query?: { search?: { title?: string; snippet?: string }[] };
    };
    return (json.query?.search ?? []).map((row) => {
      const title = row.title ?? "Wikipedia";
      const slug = encodeURIComponent(title.replace(/ /g, "_"));
      return {
        title,
        url: `https://en.wikipedia.org/wiki/${slug}`,
        snippet: (row.snippet ?? "").replace(/<[^>]+>/g, ""),
      };
    });
  } catch {
    return [];
  }
}

async function ddgSearch(query: string): Promise<Source[]> {
  try {
    const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`;
    const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return [];
    const json = (await res.json()) as {
      Heading?: string;
      AbstractText?: string;
      AbstractURL?: string;
      RelatedTopics?: { Text?: string; FirstURL?: string }[];
    };
    const hits: Source[] = [];
    if (json.AbstractText && json.AbstractURL) {
      hits.push({
        title: json.Heading || query,
        url: json.AbstractURL,
        snippet: json.AbstractText.slice(0, 280),
      });
    }
    for (const topic of json.RelatedTopics ?? []) {
      if (!topic.FirstURL || !topic.Text) continue;
      hits.push({
        title: topic.Text.slice(0, 80),
        url: topic.FirstURL,
        snippet: topic.Text.slice(0, 220),
      });
      if (hits.length >= 3) break;
    }
    return hits;
  } catch {
    return [];
  }
}

async function browse(rawUrl: string): Promise<{ url: string; title: string; excerpt: string }> {
  let current: URL;
  try {
    current = new URL(rawUrl);
  } catch {
    return { url: rawUrl, title: "Unreadable link", excerpt: "That was not a public http(s) link." };
  }
  for (let hop = 0; hop < 2; hop += 1) {
    if (!isPublicHttp(current)) {
      return { url: current.href, title: "Blocked", excerpt: "Only public http(s) pages can be read." };
    }
    const res = await fetch(current.href, {
      redirect: "manual",
      headers: { "User-Agent": "Keel/1.0 (phone coworker app; public page excerpt)" },
      signal: AbortSignal.timeout(8000),
    });
    if (res.status >= 300 && res.status < 400) {
      const next = res.headers.get("location");
      if (!next) break;
      current = new URL(next, current);
      continue;
    }
    if (!res.ok) {
      return { url: current.href, title: "Page error", excerpt: `The page returned ${res.status}.` };
    }
    const ctype = res.headers.get("content-type") ?? "";
    if (!/text|json|xml|html/i.test(ctype)) {
      return { url: current.href, title: "Not text", excerpt: "That URL is not a text page." };
    }
    const html = (await res.text()).slice(0, 120_000);
    const title = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]?.replace(/\s+/g, " ").trim() || current.hostname;
    return { url: current.href, title: title.slice(0, 140), excerpt: htmlToText(html) };
  }
  return { url: current.href, title: current.hostname, excerpt: "Could not read that page." };
}

function htmlToText(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&/g, "&")
    .replace(/</g, "<")
    .replace(/>/g, ">")
    .replace(/&#39;|'/g, "'")
    .replace(/"/g, '"')
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 1600);
}

function isPublicHttp(url: URL): boolean {
  if (url.protocol !== "http:" && url.protocol !== "https:") return false;
  const host = url.hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (
    host === "localhost" ||
    host.endsWith(".local") ||
    host.endsWith(".internal") ||
    host === "::1"
  ) {
    return false;
  }
  const match = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (!match) return true;
  const a = Number(match[1]);
  const b = Number(match[2]);
  if (a === 10 || a === 127 || a === 0) return false;
  if (a === 169 && b === 254) return false;
  if (a === 172 && b >= 16 && b <= 31) return false;
  if (a === 192 && b === 168) return false;
  return true;
}
