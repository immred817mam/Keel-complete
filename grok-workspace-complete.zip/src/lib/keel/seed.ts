import type { Bot, ChatMessage } from "@/lib/keel/types";

const BASE = Date.UTC(2026, 9, 23, 21, 20, 0);

export function sampleBots(): Bot[] {
  return [
    {
      id: "ada",
      name: "Ada Voss",
      role: "Chief of staff",
      brief:
        "Short, decisive, and calm. You turn a messy day into an ordered list. You do not cheerlead. You ask one question when something is ambiguous, never five.",
      shape: "circle",
      tone: "ink",
      status: "idle",
      statusLine: "Ready when you are.",
      updatedAt: BASE,
      unread: 0,
      memory: [
        "Prefers a decision over a menu of options.",
        "Keep plans to five lines or fewer.",
      ],
      files: [],
      sources: [],
      routines: [
        {
          id: "ada-morning",
          label: "Morning brief",
          prompt:
            "Give me a five-line brief for today. Use what you remember. If you need one decision from me, ask it at the end.",
          when: "on_open",
          lastRun: 0,
        },
      ],
      prompts: [
        "What should I clear first today?",
        "Turn this into a five-line plan: ship the notes update",
      ],
    },
    {
      id: "nia",
      name: "Nia Okonkwo",
      role: "Inbox",
      brief:
        "You triage messages and draft replies in the user's voice: warm, brief, specific. You never send. You always stop on a draft.",
      shape: "squircle",
      tone: "copper",
      status: "needs_you",
      statusLine: "Reply to Dana is waiting.",
      updatedAt: BASE + 40 * 60 * 1000,
      unread: 1,
      memory: ["Sign replies with a name only if the user has given one. Otherwise no sign-off."],
      files: [
        {
          path: "inbox/dana-thursday.md",
          content:
            "Dana asked to move Thursday's review.\nKeep it this week. Offer 3:30 if 2pm is tight.\nDo not attach the full deck.",
          updatedAt: BASE + 35 * 60 * 1000,
        },
      ],
      sources: [],
      routines: [],
      prompts: ["Make the Dana reply shorter", "Draft a thanks for the intro from Priya"],
    },
    {
      id: "jules",
      name: "Jules Hart",
      role: "Research",
      brief:
        "You look things up, then write a one-page brief on the desk. You cite public sources. You do not invent numbers. If a search is thin, you say so.",
      shape: "tile",
      tone: "ink",
      status: "done",
      statusLine: "Left a brief on the desk.",
      updatedAt: BASE + 15 * 60 * 1000,
      unread: 0,
      memory: ["Briefs stay under a page. Lead with the answer."],
      files: [
        {
          path: "briefs/open-models.md",
          content:
            "# Open models, one page\n\nThis desk runs on an open-weight model (gpt-oss 20B) through a free anonymous lane. No account, no key.\n\nWhat that means in practice:\n- Replies are real model output, not canned scripts.\n- The free lane can be slow or busy. A Groq, Gemini, or OpenRouter key in Settings is optional and stays on this phone.\n- Research still needs a source. If a lookup comes back thin, say so instead of filling the gap.\n\nUse a stronger free key when a draft has to sound like you, not like a careful intern.",
          updatedAt: BASE + 15 * 60 * 1000,
        },
      ],
      sources: [],
      routines: [],
      prompts: ["Brief me on open-weight models, one page", "What should I verify before I trust a free API?"],
    },
    {
      id: "omar",
      name: "Omar Shah",
      role: "Outreach",
      brief:
        "You draft outreach and follow-ups. Specific, never oily. You stop at a draft every time. You do not pretend a message was sent.",
      shape: "circle",
      tone: "copper",
      status: "idle",
      statusLine: "Nothing goes out without you.",
      updatedAt: BASE - 2 * 60 * 60 * 1000,
      unread: 0,
      memory: ["No exclamation marks. No 'just circling back'."],
      files: [],
      sources: [],
      routines: [],
      prompts: [
        "Draft a follow-up to a lead who went quiet after a demo",
        "Shorter, and mention Tuesday only",
      ],
    },
  ];
}

export function sampleMessages(): ChatMessage[] {
  return [
    {
      id: "m-nia-user",
      botId: "nia",
      role: "user",
      text: "Dana wants to move our Thursday review. Draft a short reply that keeps it this week.",
      at: BASE + 30 * 60 * 1000,
    },
    {
      id: "m-nia-bot",
      botId: "nia",
      role: "bot",
      text: "Thursday still works if she can slide past two. I drafted the reply and stopped.",
      at: BASE + 40 * 60 * 1000,
      activity: [{ label: "Wrote inbox/dana-thursday.md" }],
      draft: {
        channel: "email",
        title: "Reply to Dana",
        to: "Dana",
        subject: "Re: Thursday review",
        body: "Thursday still works on my side.\n\nIf 2pm is tight, 3:30 is free. I'll bring the one-page update, not the full deck.",
        state: "pending",
      },
    },
    {
      id: "m-jules-user",
      botId: "jules",
      role: "user",
      text: "Leave me a one-page note on the open model this desk uses.",
      at: BASE + 10 * 60 * 1000,
    },
    {
      id: "m-jules-bot",
      botId: "jules",
      role: "bot",
      text: "It's on the desk as briefs/open-models.md. Short version: open-weight, free lane, no key, and it will tell you when a source is thin.",
      at: BASE + 15 * 60 * 1000,
      activity: [{ label: "Wrote briefs/open-models.md" }],
    },
    {
      id: "m-omar-bot",
      botId: "omar",
      role: "bot",
      text: "Tell me who went quiet and what you last said. I'll draft the follow-up and hand it back. I don't send.",
      at: BASE - 2 * 60 * 60 * 1000,
    },
  ];
}

export const defaultSettings = {
  engine: "open" as const,
  apiKey: "",
  model: "",
  installHint: true,
};
