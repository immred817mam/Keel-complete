import { Plus, Settings } from "lucide-react";
import { Avatar, Mark } from "@/components/keel/avatar";
import { askBot } from "@/lib/keel/run";
import { useKeel } from "@/lib/keel/store";
import type { Bot, BotStatus } from "@/lib/keel/types";

export function relTime(at: number, now: number): string {
  const minutes = Math.round((now - at) / 60000);
  if (minutes < 1) return "now";
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours}h`;
  return `${Math.round(hours / 24)}d`;
}

export function dueRoutine(bot: Bot, now: number | null) {
  if (now == null) return null;
  return (
    bot.routines.find(
      (routine) => routine.when === "on_open" && now - routine.lastRun > 18 * 60 * 60 * 1000,
    ) ?? null
  );
}

function statusWord(status: BotStatus): string | null {
  if (status === "needs_you") return "Waiting";
  if (status === "working") return "Working";
  if (status === "done") return "Done";
  return null;
}

export function Roster({ now }: { now: number | null }) {
  const bots = useKeel((s) => s.bots);
  const openBotId = useKeel((s) => s.openBotId);
  const screen = useKeel((s) => s.screen);
  const installHint = useKeel((s) => s.settings.installHint);
  const engine = useKeel((s) => s.settings.engine);
  const openBot = useKeel((s) => s.openBot);
  const setSheet = useKeel((s) => s.setSheet);
  const patchBot = useKeel((s) => s.patchBot);

  const waiting = bots.filter((bot) => bot.status === "needs_you").length;
  const working = bots.filter((bot) => bot.status === "working").length;

  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="safe-top shrink-0 px-5 pb-4">
        <div className="flex items-center justify-between">
          <p className="text-xs font-medium tracking-widest text-copper">KEEL</p>
          <div className="flex items-center gap-1">
            <button
              type="button"
              className="inline-flex size-11 items-center justify-center rounded-full text-ink"
              aria-label="New coworker"
              onClick={() => setSheet("create")}
            >
              <Plus className="size-5" />
            </button>
            <button
              type="button"
              className="inline-flex size-11 items-center justify-center rounded-full text-ink"
              aria-label="Settings"
              onClick={() => setSheet("settings")}
            >
              <Settings className="size-5" />
            </button>
          </div>
        </div>
        <h1 className="font-display text-4xl leading-none text-balance">Desk</h1>
        <p className="mt-2 max-w-xs text-sm text-pretty text-muted">
          Coworkers that research, draft, and wait for your OK.
        </p>
        <p className="mt-4 text-sm tabular-nums text-ink">
          {waiting > 0 ? `${waiting} waiting` : "None waiting"}
          <span className="text-muted"> · </span>
          {working > 0 ? `${working} working` : `${bots.length} on the desk`}
        </p>
      </header>

      {installHint ? (
        <button
          type="button"
          className="mx-4 mb-3 flex items-center justify-between gap-3 rounded-2xl bg-ink px-4 py-3 text-left text-copper-ink"
          onClick={() => setSheet("install")}
        >
          <span>
            <span className="block text-sm font-medium">Add Keel to your phone</span>
            <span className="mt-0.5 block text-xs text-copper-soft">
              Android home screen. Your desk stays on the device.
            </span>
          </span>
          <Mark className="size-10" />
        </button>
      ) : null}

      <div className="keel-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-8">
        {bots.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-line px-4 py-8 text-center">
            <p className="font-display text-2xl text-balance">The desk is empty.</p>
            <p className="mt-2 text-sm text-pretty text-muted">
              Add a coworker, or bring back the sample desk from Settings.
            </p>
            <button
              type="button"
              className="mt-4 inline-flex h-11 items-center rounded-full bg-copper px-4 text-sm font-medium text-copper-ink"
              onClick={() => setSheet("create")}
            >
              New coworker
            </button>
          </div>
        ) : (
          <ul className="flex flex-col gap-2">
            {bots
              .slice()
              .sort((a, b) => b.updatedAt - a.updatedAt)
              .map((bot) => {
                const word = statusWord(bot.status);
                const selected = openBotId === bot.id && screen !== "roster";
                const due = dueRoutine(bot, now);
                return (
                  <li key={bot.id} className={`rounded-2xl border bg-sheet ${selected ? "border-ink" : "border-line"}`}>
                    <button
                      type="button"
                      className="flex w-full items-start gap-3 px-3 py-3 text-left"
                      onClick={() => openBot(bot.id)}
                    >
                      <Avatar bot={bot} />
                      <span className="min-w-0 flex-1">
                        <span className="flex items-baseline justify-between gap-2">
                          <span className="truncate font-display text-xl leading-tight">{bot.name}</span>
                          <span className="shrink-0 text-xs tabular-nums text-muted">
                            {now == null ? "" : relTime(bot.updatedAt, now)}
                          </span>
                        </span>
                        <span className="mt-0.5 block truncate text-xs text-muted">{bot.role}</span>
                        <span className="mt-1 block truncate text-sm text-ink">{bot.statusLine}</span>
                        {word ? (
                          <span
                            className={`mt-1 inline-flex items-center gap-1.5 text-xs font-medium ${word === "Waiting" ? "text-copper" : "text-muted"}`}
                          >
                            {bot.status === "working" ? (
                              <span className="pulse-dot size-1.5 rounded-full bg-copper" />
                            ) : null}
                            {word}
                            {bot.unread > 0 ? ` · ${bot.unread} new` : ""}
                          </span>
                        ) : bot.unread > 0 ? (
                          <span className="mt-1 block text-xs font-medium text-copper">{bot.unread} new</span>
                        ) : null}
                      </span>
                    </button>
                    {due && bot.status !== "working" ? (
                      <div className="px-3 pb-3">
                        <button
                          type="button"
                          className="inline-flex h-10 items-center rounded-full border border-line px-3 text-sm"
                          onClick={() => {
                            patchBot(bot.id, {
                              routines: bot.routines.map((routine) =>
                                routine.id === due.id ? { ...routine, lastRun: Date.now() } : routine,
                              ),
                            });
                            askBot(bot.id, due.prompt);
                          }}
                        >
                          Run {due.label}
                        </button>
                      </div>
                    ) : null}
                  </li>
                );
              })}
          </ul>
        )}
        <p className="px-1 pt-4 text-xs text-muted">
          {engine === "open"
            ? "Open model · gpt-oss 20B · free, no key"
            : `Using your ${engine} key · stays on this phone`}
        </p>
      </div>
    </div>
  );
}

export function QuietDesk() {
  return (
    <div className="flex h-full flex-col justify-center px-8">
      <Mark />
      <h2 className="mt-6 max-w-sm font-display text-4xl text-balance">A desk, not a chat window.</h2>
      <p className="mt-3 max-w-sm text-pretty text-muted">
        Pick someone. They look things up, leave files, and stop when a message should leave the phone.
      </p>
      <ol className="mt-8 max-w-md space-y-3">
        {[
          ["01", "Message them like a teammate"],
          ["02", "Watch the search, the file, the draft"],
          ["03", "Share it yourself. They never send"],
        ].map(([n, label]) => (
          <li key={n} className="flex items-center gap-3 text-sm">
            <span className="font-display text-lg text-copper">{n}</span>
            {label}
          </li>
        ))}
      </ol>
    </div>
  );
}
