import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  Check,
  Copy,
  FolderOpen,
  Mic,
  Pencil,
  Send,
  Share2,
  Square,
  Volume2,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { Avatar } from "@/components/keel/avatar";
import { askBot, saveDraftFile, stopBot } from "@/lib/keel/run";
import { uid, useKeel } from "@/lib/keel/store";
import type { Bot, DraftCard } from "@/lib/keel/types";

type Rec = {
  lang: string;
  start: () => void;
  stop: () => void;
  onresult: ((event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onend: (() => void) | null;
};

type RecCtor = new () => Rec;

function recCtor(): RecCtor | null {
  if (typeof window === "undefined") return null;
  const w = window as Window & { SpeechRecognition?: RecCtor; webkitSpeechRecognition?: RecCtor };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

function draftText(draft: DraftCard): string {
  const head = [
    draft.to ? `To: ${draft.to}` : "",
    draft.subject ? `Subject: ${draft.subject}` : "",
  ].filter(Boolean);
  return [...head, head.length ? "" : "", draft.body].join("\n").trim();
}

async function shareOrCopy(title: string, text: string): Promise<"shared" | "copied" | "cancel"> {
  if (typeof navigator.share === "function") {
    try {
      await navigator.share({ title, text });
      return "shared";
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") return "cancel";
    }
  }
  try {
    await navigator.clipboard.writeText(text);
    return "copied";
  } catch {
    return "cancel";
  }
}

function safeHref(url: string): string | null {
  if (/^https?:\/\//i.test(url)) return url;
  return null;
}

export function Chat({ bot }: { bot: Bot }) {
  const allMessages = useKeel((s) => s.messages);
  const messages = allMessages.filter((message) => message.botId === bot.id);
  const setScreen = useKeel((s) => s.setScreen);
  const setSheet = useKeel((s) => s.setSheet);
  const patchMessage = useKeel((s) => s.patchMessage);
  const addMessage = useKeel((s) => s.addMessage);
  const [text, setText] = useState("");
  const [listening, setListening] = useState(false);
  const [canListen, setCanListen] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);
  const recRef = useRef<Rec | null>(null);
  const last = messages[messages.length - 1];

  useEffect(() => {
    setCanListen(recCtor() != null);
  }, []);

  useEffect(() => {
    const node = scroller.current;
    if (!node) return;
    node.scrollTop = node.scrollHeight;
  }, [messages.length, last?.text, bot.status, bot.statusLine]);

  function send(value = text) {
    const next = value.trim();
    if (!next || bot.status === "working") return;
    setText("");
    askBot(bot.id, next);
  }

  function toggleMic() {
    const Ctor = recCtor();
    if (!Ctor) return;
    if (listening) {
      recRef.current?.stop();
      setListening(false);
      return;
    }
    const rec = new Ctor();
    rec.lang = "en-US";
    rec.onresult = (event) => {
      const said = Array.from(event.results)
        .map((result) => result[0]?.transcript ?? "")
        .join(" ")
        .trim();
      if (said) setText((current) => (current ? `${current} ${said}` : said));
    };
    rec.onend = () => setListening(false);
    recRef.current = rec;
    rec.start();
    setListening(true);
  }

  const showTyping = bot.status === "working" && last?.role !== "bot";

  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="safe-top flex shrink-0 items-center gap-2 border-b border-line px-2 pb-3">
        <button
          type="button"
          className="inline-flex size-11 items-center justify-center rounded-full lg:hidden"
          aria-label="Back to desk"
          onClick={() => setScreen("roster")}
        >
          <ArrowLeft className="size-5" />
        </button>
        <Avatar bot={bot} className="size-10" />
        <button type="button" className="min-w-0 flex-1 text-left" onClick={() => setSheet("edit")}>
          <span className="block truncate font-display text-xl leading-tight">{bot.name}</span>
          <span className="block truncate text-xs text-muted">
            {bot.role}
            {bot.status === "working" ? " · Working" : bot.status === "needs_you" ? " · Waiting" : ""}
          </span>
        </button>
        <button
          type="button"
          className="inline-flex size-11 items-center justify-center rounded-full"
          aria-label="Open desk files"
          onClick={() => setScreen("computer")}
        >
          <FolderOpen className="size-5" />
        </button>
      </header>

      <div ref={scroller} className="keel-scroll min-h-0 flex-1 overflow-y-auto px-4 py-4">
        <ul className="mx-auto flex max-w-2xl flex-col gap-3">
          {messages.length === 0 ? (
            <li className="px-2 py-8 text-center">
              <p className="font-display text-2xl text-balance">Ask {bot.name.split(" ")[0]} for the work.</p>
              <p className="mt-2 text-sm text-pretty text-muted">{bot.brief}</p>
            </li>
          ) : null}
          {messages.map((message) => (
            <li key={message.id} className={message.role === "user" ? "flex justify-end" : "flex justify-start"}>
              {message.role === "user" ? (
                <p className="max-w-[85%] rounded-2xl rounded-br-md bg-copper px-4 py-3 text-sm text-pretty whitespace-pre-wrap text-copper-ink">
                  {message.text}
                </p>
              ) : (
                <div className="max-w-[92%] rounded-2xl rounded-bl-md border border-line bg-sheet px-4 py-3">
                  <p className="text-sm text-pretty whitespace-pre-wrap">{message.text}</p>
                  {message.activity && message.activity.length > 0 ? (
                    <ul className="mt-3 space-y-2 border-t border-line pt-3">
                      {message.activity.map((item, index) => (
                        <li key={`${message.id}-${index}`} className="text-xs text-muted">
                          <span className="font-medium text-ink">{item.label}</span>
                          {item.detail ? <span> · {item.detail}</span> : null}
                          {item.links && item.links.length > 0 ? (
                            <span className="mt-1 flex flex-col gap-1">
                              {item.links.map((link) => {
                                const href = safeHref(link.url);
                                return href ? (
                                  <a
                                    key={href}
                                    href={href}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="truncate text-copper underline"
                                  >
                                    {link.title || href}
                                  </a>
                                ) : (
                                  <span key={link.title}>{link.title}</span>
                                );
                              })}
                            </span>
                          ) : null}
                        </li>
                      ))}
                    </ul>
                  ) : null}
                  {message.draft ? (
                    <DraftBlock
                      draft={message.draft}
                      onChange={(draft) => patchMessage(message.id, { draft })}
                      onResolve={(draft, note) => {
                        patchMessage(message.id, { draft });
                        addMessage({
                          id: uid(),
                          botId: bot.id,
                          role: "bot",
                          text: note,
                          at: Date.now(),
                        });
                      }}
                      bot={bot}
                    />
                  ) : null}
                  <button
                    type="button"
                    className="mt-2 inline-flex size-9 items-center justify-center rounded-full text-muted"
                    aria-label="Read aloud"
                    onClick={() => {
                      if (!window.speechSynthesis) return;
                      window.speechSynthesis.cancel();
                      window.speechSynthesis.speak(new SpeechSynthesisUtterance(message.text));
                    }}
                  >
                    <Volume2 className="size-4" />
                  </button>
                </div>
              )}
            </li>
          ))}
          {showTyping ? (
            <li className="flex items-center gap-2 text-sm text-muted">
              <span className="pulse-dot size-2 rounded-full bg-copper" />
              {bot.name.split(" ")[0]} is working
            </li>
          ) : null}
        </ul>
      </div>

      <div className="safe-bottom shrink-0 border-t border-line px-3 pt-2">
        {bot.status !== "working" && bot.prompts.length > 0 ? (
          <div className="no-scrollbar mb-2 flex gap-2 overflow-x-auto">
            {bot.prompts.map((prompt) => (
              <button
                key={prompt}
                type="button"
                className="shrink-0 rounded-full border border-line bg-sheet px-3 py-2 text-left text-xs"
                onClick={() => send(prompt)}
              >
                {prompt}
              </button>
            ))}
          </div>
        ) : null}
        <form
          className="mx-auto flex max-w-2xl items-end gap-2 pb-2"
          onSubmit={(event) => {
            event.preventDefault();
            send();
          }}
        >
          {canListen ? (
            <button
              type="button"
              className={`inline-flex size-11 shrink-0 items-center justify-center rounded-full border border-line ${listening ? "bg-copper text-copper-ink" : "bg-sheet"}`}
              aria-label={listening ? "Stop dictation" : "Dictate"}
              onClick={toggleMic}
            >
              <Mic className="size-5" />
            </button>
          ) : null}
          <label className="min-w-0 flex-1">
            <span className="sr-only">Message {bot.name}</span>
            <textarea
              value={text}
              rows={1}
              placeholder={`Message ${bot.name.split(" ")[0]}`}
              className="max-h-32 w-full resize-none rounded-2xl border border-line bg-sheet px-4 py-3 text-sm outline-none"
              onChange={(event) => setText(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter" && !event.shiftKey) {
                  event.preventDefault();
                  send();
                }
              }}
            />
          </label>
          {bot.status === "working" ? (
            <button
              type="button"
              className="inline-flex size-11 shrink-0 items-center justify-center rounded-full bg-ink text-copper-ink"
              aria-label="Stop"
              onClick={() => stopBot(bot.id)}
            >
              <Square className="size-4" />
            </button>
          ) : (
            <button
              type="submit"
              className="inline-flex size-11 shrink-0 items-center justify-center rounded-full bg-copper text-copper-ink disabled:opacity-40"
              aria-label="Send"
              disabled={!text.trim()}
            >
              <Send className="size-4" />
            </button>
          )}
        </form>
      </div>
    </div>
  );
}

function DraftBlock({
  draft,
  bot,
  onChange,
  onResolve,
}: {
  draft: DraftCard;
  bot: Bot;
  onChange: (draft: DraftCard) => void;
  onResolve: (draft: DraftCard, note: string) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [body, setBody] = useState(draft.body);
  const pending = draft.state === "pending";

  async function share() {
    const next = { ...draft, body };
    const mode = await shareOrCopy(next.title, draftText(next));
    if (mode === "cancel") return;
    const path = saveDraftFile(bot, next);
    onResolve(
      { ...next, state: "approved" },
      mode === "shared"
        ? `Share sheet opened. A copy is on the desk at ${path}.`
        : `Copied. A copy is on the desk at ${path}. Paste it where it should go.`,
    );
    toast(mode === "shared" ? "Opened the share sheet" : "Copied the draft");
  }

  function saveOnly() {
    const next = { ...draft, body };
    const path = saveDraftFile(bot, next);
    onResolve({ ...next, state: "approved" }, `Saved on the desk at ${path}. Nothing was sent.`);
    toast("Saved on the desk");
  }

  function discard() {
    onResolve({ ...draft, body, state: "discarded" }, "Discarded. Nothing was shared.");
  }

  return (
    <div className="mt-3 rounded-xl bg-copper-soft p-3 text-ink">
      <p className="text-xs font-medium tracking-wide text-copper">
        {pending ? "Needs your OK" : draft.state === "approved" ? "Approved" : "Discarded"}
        <span className="text-muted"> · {draft.channel}</span>
      </p>
      <p className="mt-1 font-display text-lg leading-tight">{draft.title}</p>
      {draft.to ? <p className="mt-1 text-xs text-muted">To {draft.to}</p> : null}
      {draft.subject ? <p className="text-xs text-muted">{draft.subject}</p> : null}
      {editing ? (
        <textarea
          value={body}
          rows={5}
          className="mt-2 w-full resize-none rounded-lg border border-line bg-sheet px-3 py-2 text-sm outline-none"
          onChange={(event) => setBody(event.target.value)}
        />
      ) : (
        <p className="mt-2 text-sm whitespace-pre-wrap">{body}</p>
      )}
      {pending ? (
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            type="button"
            className="inline-flex h-11 items-center gap-2 rounded-full bg-copper px-4 text-sm font-medium text-copper-ink"
            onClick={() => void share()}
          >
            <Share2 className="size-4" />
            Share
          </button>
          <button
            type="button"
            className="inline-flex h-11 items-center gap-2 rounded-full border border-line bg-sheet px-4 text-sm"
            onClick={saveOnly}
          >
            <Check className="size-4" />
            Save
          </button>
          <button
            type="button"
            className="inline-flex h-11 items-center gap-2 rounded-full px-3 text-sm text-muted"
            onClick={() => setEditing((value) => !value)}
          >
            <Pencil className="size-4" />
            {editing ? "Done editing" : "Edit"}
          </button>
          <button
            type="button"
            className="inline-flex h-11 items-center gap-2 rounded-full px-3 text-sm text-muted"
            onClick={discard}
          >
            <X className="size-4" />
            Discard
          </button>
        </div>
      ) : (
        <button
          type="button"
          className="mt-3 inline-flex h-10 items-center gap-2 text-sm text-copper"
          onClick={() => {
            void navigator.clipboard.writeText(draftText({ ...draft, body })).then(() => {
              toast("Copied");
            });
          }}
        >
          <Copy className="size-4" />
          Copy
        </button>
      )}
    </div>
  );
}
