import type { Bot } from "@/lib/keel/types";

export function Mark({ className = "size-12" }: { className?: string }) {
  return (
    <span
      className={`inline-flex items-center justify-center rounded-2xl bg-ink text-copper ${className}`}
      aria-hidden="true"
    >
      <svg viewBox="0 0 32 32" className="size-6">
        <path
          d="M5 12.2 L16 17.2 L27 12.2"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.6"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M16 17.2 V25"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.6"
          strokeLinecap="round"
        />
      </svg>
    </span>
  );
}

export function Avatar({ bot, className = "size-12" }: { bot: Bot; className?: string }) {
  const initial = bot.name.trim().charAt(0).toUpperCase() || "K";
  const tone = bot.tone === "copper" ? "bg-copper text-copper-ink" : "bg-ink text-copper-ink";
  const shape =
    bot.shape === "circle" ? "rounded-full" : bot.shape === "squircle" ? "rounded-2xl" : "rounded-md";
  return (
    <span
      className={`inline-flex shrink-0 items-center justify-center font-display text-lg ${tone} ${shape} ${className}`}
      aria-hidden="true"
    >
      {initial}
    </span>
  );
}
